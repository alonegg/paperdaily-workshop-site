# PaperDaily 工作坊海报 · HTML 编辑包

活动：如何把 PaperDaily 作为你的科研外脑。11 月 5 日上午，主讲人陈春林。

## 打开与修改

1. 解压后，双击 `poster/index.html` 即可查看海报。请保留文件夹结构，图片和字体使用相对路径。
2. 简单修改可直接编辑 `poster/index.html` 中的文字或 CSS。
3. 需要保留可复用文案时，编辑 `poster/copy.json`（文案）及 `poster/template.html`（版式），然后在本文件所在目录执行：

   ```sh
   python3 poster/render_html.py
   ```

   这一步会覆盖 `poster/index.html`，不需要安装 Python 第三方依赖。
4. 如果修改了 `preparation_url`，还需重新生成二维码，再运行 HTML 渲染：

   ```sh
   uv run --with qrcode python poster/generate_qr.py
   python3 poster/render_html.py
   ```

   此步骤需要 `uv`，会从 Python package registry 获取 `qrcode`。

## 文件与字体

- `poster/index.html`：可离线打开的活动海报；窄屏自动等比缩放。
- `poster/copy.json`、`poster/template.html`：文案和版式。
- `poster/render_html.py`、`poster/generate_qr.py`：HTML 渲染和二维码生成工具。
- `poster/assets/`：品牌标识、AI 生成的无文字插画和会前准备二维码。
- `workshop/assets/fonts/`：思印宋标题字体与 OFL 许可；未打包 macOS 系统字体。正文按设备使用 Heiti SC、PingFang SC 或 Microsoft YaHei 等本机字体。

海报页面只展示海报，编辑包下载入口位于 Workshop 首页。需要分享图片或 PDF 时，可自行从浏览器导出；本包未附带旧版主题 PDF 或 PNG。

在线海报：https://workshop.paperdaily.org/poster/

会前准备与 skills 下载：https://workshop.paperdaily.org/prepare/

修改后请将 HTML、文案、模板及有改动的素材一起交回维护者。网站不会自动读取你电脑上的修改，须由维护者提交到源仓库后发布。
