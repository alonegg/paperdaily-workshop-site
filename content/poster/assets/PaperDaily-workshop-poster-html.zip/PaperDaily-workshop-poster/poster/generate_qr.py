"""Generate the preparation QR asset from editable poster copy.

Run with: uv run --with qrcode python poster/generate_qr.py
"""
import json
from pathlib import Path

import qrcode
from qrcode.image.svg import SvgPathFillImage

ROOT = Path(__file__).resolve().parent


def main() -> None:
    copy = json.loads((ROOT / "copy.json").read_text())
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M,
                       box_size=10, border=4)
    qr.add_data(copy["preparation_url"])
    qr.make(fit=True)
    qr.make_image(image_factory=SvgPathFillImage).save(
        ROOT / "assets/prepare-qr.svg"
    )


if __name__ == "__main__":
    main()
