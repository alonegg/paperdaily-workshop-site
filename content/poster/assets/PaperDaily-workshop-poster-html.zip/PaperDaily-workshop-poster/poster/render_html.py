"""Render the editable poster HTML without PDF dependencies."""
from pathlib import Path
import html
import json

ROOT = Path(__file__).resolve().parent

def render_html() -> None:
    values = json.loads((ROOT / "copy.json").read_text())
    source = (ROOT / "template.html").read_text()
    for key, value in values.items():
        source = source.replace("{{" + key + "}}", html.escape(value))
    if "{{" in source:
        raise ValueError("Unresolved poster template field")
    (ROOT / "index.html").write_text(source)

if __name__ == "__main__":
    render_html()
